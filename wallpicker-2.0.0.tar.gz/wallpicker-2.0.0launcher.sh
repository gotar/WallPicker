#!/bin/bash
cd "$(dirname "$0")"
mise exec -- python launcher.py
