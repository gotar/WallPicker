#!/usr/bin/env python3
import asyncio
import os
import sys

from gi.events import GLibEventLoopPolicy

# Add src directory to path
src_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
sys.path.insert(0, src_path)  # noqa: E402

from ui.main_window import MainWindow  # noqa: E402


def main():
    asyncio.set_event_loop_policy(GLibEventLoopPolicy())

    debug = "--debug" in sys.argv
    if debug:
        sys.argv.remove("--debug")

    app = MainWindow(debug=debug)
    app.run()


if __name__ == "__main__":
    main()
