"""Wallpicker - Modern wallpaper picker application."""

__version__ = "1.1.1"
