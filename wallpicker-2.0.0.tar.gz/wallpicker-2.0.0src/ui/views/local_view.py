"""View for local wallpaper browsing."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gdk, GLib, GObject, Gtk, Pango  # noqa: E402

from ui.components.search_filter_bar import SearchFilterBar  # noqa: E402
from ui.view_models.local_view_model import LocalViewModel  # noqa: E402


class LocalView(Adw.BreakpointBin):
    """View for local wallpaper browsing with adaptive layout"""

    def __init__(
        self,
        view_model: LocalViewModel,
        banner_service=None,
        toast_service=None,
        thumbnail_loader=None,
        on_set_wallpaper=None,
        on_delete=None,
    ):
        super().__init__()
        self.view_model = view_model
        self.banner_service = banner_service
        self.toast_service = toast_service
        self.thumbnail_loader = thumbnail_loader
        self.on_set_wallpaper = on_set_wallpaper
        self.on_delete = on_delete
        self._last_selected_wallpaper = None
        self._search_debounce_timer = None

        self._create_ui()

        self._setup_keyboard_shortcuts()
        self._bind_to_view_model()

    def _create_ui(self):
        """Create main UI structure"""
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.set_child(self.main_box)

        self._create_filter_bar()
        self._create_wallpaper_grid()
        self._create_status_bar()

    def _create_filter_bar(self):
        """Create unified filter bar for local wallpapers"""
        toolbar_wrapper = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        toolbar_wrapper.add_css_class("toolbar-wrapper")
        self.main_box.append(toolbar_wrapper)

        folder_btn = Gtk.Button(
            icon_name="folder-symbolic", tooltip_text="Choose folder"
        )
        folder_btn.connect("clicked", self._on_folder_clicked)
        toolbar_wrapper.append(folder_btn)

        self.search_filter_bar = SearchFilterBar(
            tab_type="local",
            on_search_changed=self._on_search_changed,
            on_sort_changed=self._on_sort_changed,
        )
        toolbar_wrapper.append(self.search_filter_bar)

        self.loading_spinner = Gtk.Spinner(spinning=False)
        toolbar_wrapper.append(self.loading_spinner)

    def _on_search_changed(self, text: str):
        if self._search_debounce_timer:
            GLib.source_remove(self._search_debounce_timer)

        self.view_model.search_query = text
        self._search_debounce_timer = GLib.timeout_add(300, self._trigger_search)

    def _trigger_search(self) -> bool:
        if self._search_debounce_timer:
            self._search_debounce_timer = None

        self.view_model.search_wallpapers(self.view_model.search_query)
        return False  # Don't repeat timer

    def _on_sort_changed(self, sorting: str):
        if sorting == "name":
            self.view_model.sort_by_name()
        elif sorting == "date":
            self.view_model.sort_by_date()

    def update_status(self, count: int):
        self.status_label.set_text(f"{count} wallpapers")

    def _create_wallpaper_grid(self):
        """Create wallpaper grid display"""
        self.scroll = Gtk.ScrolledWindow()
        self.scroll.set_vexpand(True)

        # Create flow box for wallpaper grid
        self.wallpaper_grid = Gtk.FlowBox()
        self.wallpaper_grid.set_homogeneous(True)
        self.wallpaper_grid.set_min_children_per_line(4)
        self.wallpaper_grid.set_max_children_per_line(12)
        self.wallpaper_grid.set_column_spacing(12)
        self.wallpaper_grid.set_row_spacing(12)
        self.wallpaper_grid.set_selection_mode(Gtk.SelectionMode.NONE)
        self.scroll.set_child(self.wallpaper_grid)

        self.main_box.append(self.scroll)

    def _create_status_bar(self):
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        status_box.add_css_class("status-bar")
        status_box.set_halign(Gtk.Align.CENTER)
        self.status_label = Gtk.Label(label="")
        status_box.append(self.status_label)
        self.main_box.append(status_box)

    def _bind_to_view_model(self):
        GObject.Object.bind_property(
            self.view_model,
            "is-busy",
            self.loading_spinner,
            "spinning",
            GObject.BindingFlags.DEFAULT,
        )
        self.view_model.connect("notify::wallpapers", self._on_wallpapers_changed)
        self.view_model.connect("notify::selected-count", self._on_selection_changed)

    def _setup_keyboard_shortcuts(self):
        key_controller = Gtk.EventControllerKey()
        key_controller.connect("key-pressed", self._on_key_pressed)
        self.add_controller(key_controller)

        # Setup grid navigation
        self._setup_grid_navigation()

    def _setup_grid_navigation(self):
        """Setup keyboard navigation for wallpaper grid."""
        # Add key controller to flow box for arrow key navigation
        grid_key_controller = Gtk.EventControllerKey()
        grid_key_controller.connect("key-pressed", self._on_grid_key_pressed)
        self.wallpaper_grid.add_controller(grid_key_controller)

        # Track card->wallpaper mapping for keyboard activation
        self.card_wallpaper_map = {}

    def _on_grid_key_pressed(self, controller, keyval, keycode, state):
        """Handle keyboard navigation within grid."""
        # Arrow keys: Navigate between cards
        if keyval == Gdk.KEY_Down:
            self._focus_next_card()
            return True
        elif keyval == Gdk.KEY_Up:
            self._focus_prev_card()
            return True
        elif keyval == Gdk.KEY_Right:
            self._focus_next_card()
            return True
        elif keyval == Gdk.KEY_Left:
            self._focus_prev_card()
            return True
        # Enter/Return: Set wallpaper
        elif keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            focused = self.wallpaper_grid.get_focus_child()
            if focused and focused in self.card_wallpaper_map:
                wallpaper = self.card_wallpaper_map[focused]
                self._on_set_wallpaper(None, wallpaper)
            return True
        # Space: Toggle favorite
        elif keyval == Gdk.KEY_space:
            focused = self.wallpaper_grid.get_focus_child()
            if focused and focused in self.card_wallpaper_map:
                wallpaper = self.card_wallpaper_map[focused]
                self._on_add_to_favorites(None, wallpaper)
            return True
        elif keyval == Gdk.KEY_Escape:
            self.view_model.clear_selection()
            return True
        return False

    def _focus_next_card(self):
        """Focus next card in grid."""
        current = self.wallpaper_grid.get_focus_child()
        if not current:
            # Focus first card if none focused
            first = self.wallpaper_grid.get_first_child()
            if first:
                first.grab_focus()
            return

        # Get all children
        children = []
        child = self.wallpaper_grid.get_first_child()
        while child:
            children.append(child)
            child = child.get_next_sibling()

        if not children:
            return

        current_idx = children.index(current)
        next_idx = (current_idx + 1) % len(children)
        children[next_idx].grab_focus()

    def _focus_prev_card(self):
        """Focus previous card in grid."""
        current = self.wallpaper_grid.get_focus_child()
        if not current:
            # Focus last card if none focused
            last = self.wallpaper_grid.get_first_child()
            while last and last.get_next_sibling():
                last = last.get_next_sibling()
            if last:
                last.grab_focus()
            return

        # Get all children
        children = []
        child = self.wallpaper_grid.get_first_child()
        while child:
            children.append(child)
            child = child.get_next_sibling()

        if not children:
            return

        current_idx = children.index(current)
        prev_idx = (current_idx - 1) % len(children)
        children[prev_idx].grab_focus()

    def _setup_pull_to_refresh(self):
        """Setup pull-to-refresh gesture on scrolled window."""
        self.is_refreshing = False

        # Swipe controller for pull gesture
        swipe = Gtk.GestureSwipe()
        swipe.set_propagation_phase(Gtk.PropagationPhase.BUBBLE)
        swipe.connect("swipe", self._on_pull_swipe)
        self.scroll.add_controller(swipe)

    def _on_pull_swipe(self, gesture, dx, dy):
        """Handle pull-down gesture for refresh."""
        # Only trigger on vertical pull (dy < 0) and near top of scroll
        vadj = self.scroll.get_vadjustment()
        current_value = vadj.get_value()

        # Check if we're at the top of the scroll and pulling down
        if dy < -100 and current_value < 50 and not self.is_refreshing:
            self.is_refreshing = True
            self.view_model.refresh_wallpapers()

            # Reset flag after a delay
            from gi.repository import GLib  # noqa: E402

            GLib.timeout_add(1000, self._reset_refresh_flag)

    def _on_key_pressed(self, controller, keyval, keycode, state):
        if state & Gdk.ModifierType.CONTROL_MASK and keyval == Gdk.KEY_a:
            self.view_model.select_all()
            return True
        elif keyval == Gdk.KEY_Escape:
            self.view_model.clear_selection()
            return True
        return False

    def _on_selection_changed(self, obj, pspec):
        count = self.view_model.selected_count
        if count > 0 and self.banner_service:
            self.banner_service.show_selection_banner(
                count=count, on_set_all=self._on_set_all_selected
            )
        elif count == 0 and self.banner_service:
            self.banner_service.hide_selection_banner()

    def _on_set_all_selected(self):
        selected = self.view_model.get_selected_wallpapers()
        for wallpaper in selected:
            success, message = self.view_model.set_wallpaper(wallpaper)
            if success and self.toast_service:
                self.toast_service.show_success(message)
            break
        self.view_model.clear_selection()

    def _on_folder_clicked(self, button):
        window = self.get_root()
        dialog = Gtk.FileDialog()
        dialog.set_title("Choose wallpapers folder")

        def on_folder_selected(dialog, result):
            try:
                folder = dialog.select_folder_finish(result)
                if folder:
                    path = Path(folder.get_path())
                    self.view_model.set_pictures_dir(path)
            except (RuntimeError, TypeError) as e:
                import logging

                logger = logging.getLogger(__name__)
                logger.debug(f"Could not get folder path from dialog: {e}")

        dialog.select_folder(window, None, on_folder_selected)

    def _on_wallpapers_changed(self, obj, pspec):
        """Handle wallpapers property change"""
        self.update_wallpaper_grid(self.view_model.wallpapers)
        self.update_status(len(self.view_model.wallpapers))

    def update_wallpaper_grid(self, wallpapers):
        """Update wallpaper grid with new wallpapers"""

        def clear_and_update():
            while child := self.wallpaper_grid.get_first_child():
                self.wallpaper_grid.remove(child)

            self.card_wallpaper_map.clear()

            for wallpaper in wallpapers:
                card = self._create_wallpaper_card(wallpaper)
                self.wallpaper_grid.append(card)

            return False

        GLib.idle_add(clear_and_update)

    def _create_wallpaper_card(self, wallpaper):
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        card.set_hexpand(True)
        card.add_css_class("wallpaper-card")

        # Make card focusable
        card.set_can_focus(True)
        card.set_focusable(True)

        # Store mapping for keyboard activation
        self.card_wallpaper_map[card] = wallpaper

        gesture = Gtk.GestureClick()
        gesture.set_button(1)
        gesture.connect("pressed", self._on_card_clicked, wallpaper)
        card.add_controller(gesture)

        is_selected = wallpaper in self.view_model.get_selected_wallpapers()
        if is_selected:
            card.add_css_class("selected")
        if self.view_model.selection_mode:
            card.add_css_class("selection-mode")

        image = Gtk.Picture()
        image.set_size_request(200, 160)
        image.set_content_fit(Gtk.ContentFit.CONTAIN)
        image.add_css_class("wallpaper-thumb")

        def on_thumbnail_loaded(texture):
            if texture:
                image.set_paintable(texture)

        thumb_path = str(wallpaper.path)
        if self.thumbnail_loader:
            self.thumbnail_loader.load_thumbnail_async(thumb_path, on_thumbnail_loaded)

        card.append(image)

        # Info box with filename and metadata
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info_box.add_css_class("card-info-box")

        # Filename
        filename_label = Gtk.Label()
        filename_label.set_ellipsize(Pango.EllipsizeMode.END)
        filename_label.set_lines(1)
        filename_label.set_max_width_chars(35)
        filename_label.set_halign(Gtk.Align.CENTER)
        filename_label.set_text(wallpaper.filename)
        filename_label.add_css_class("filename-label")
        info_box.append(filename_label)

        # Metadata (resolution • size • aspect ratio)
        metadata_label = Gtk.Label()
        metadata_parts = []

        if wallpaper.resolution:
            metadata_parts.append(wallpaper.resolution)

        if wallpaper.size:
            size = wallpaper.size
            if size >= 1024 * 1024:
                size_str = f"{size / (1024 * 1024):.1f} MB"
            elif size >= 1024:
                size_str = f"{size / 1024:.1f} KB"
            else:
                size_str = f"{size} B"
            metadata_parts.append(size_str)

        metadata_label.set_text(" • ".join(metadata_parts) if metadata_parts else "")
        metadata_label.add_css_class("metadata-label")
        info_box.append(metadata_label)

        card.append(info_box)

        # Actions box
        actions_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        actions_box.add_css_class("card-actions-box")
        actions_box.set_halign(Gtk.Align.CENTER)

        set_btn = Gtk.Button(
            icon_name="image-x-generic-symbolic", tooltip_text="Set as wallpaper"
        )
        set_btn.add_css_class("action-button")
        set_btn.add_css_class("suggested-action")
        set_btn.set_cursor_from_name("pointer")
        set_btn.connect("clicked", self._on_set_wallpaper, wallpaper)
        actions_box.append(set_btn)

        fav_btn = Gtk.Button(
            icon_name="starred-symbolic", tooltip_text="Add to favorites"
        )
        fav_btn.add_css_class("action-button")
        fav_btn.add_css_class("favorite-action")
        fav_btn.set_cursor_from_name("pointer")
        fav_btn.connect("clicked", self._on_add_to_favorites, wallpaper)
        actions_box.append(fav_btn)

        delete_btn = Gtk.Button(icon_name="user-trash-symbolic", tooltip_text="Delete")
        delete_btn.add_css_class("action-button")
        delete_btn.add_css_class("destructive-action")
        delete_btn.set_cursor_from_name("pointer")
        delete_btn.connect("clicked", self._on_delete_wallpaper, wallpaper)
        actions_box.append(delete_btn)

        card.append(actions_box)
        return card

    def _on_card_clicked(self, gesture, n_press, x, y, wallpaper):
        if n_press == 2:
            self._on_set_wallpaper(None, wallpaper)

    def _on_selection_toggled(self, wallpaper, is_selected):
        self.view_model.toggle_selection(wallpaper)

    def _on_set_wallpaper(self, button, wallpaper):
        success, message = self.view_model.set_wallpaper(wallpaper)
        if success:
            if self.toast_service:
                self.toast_service.show_success(message)
        else:
            if self.toast_service:
                self.toast_service.show_error(message)

    def _on_add_to_favorites(self, button, wallpaper):
        success, message = self.view_model.add_to_favorites(wallpaper)
        if success:
            if self.toast_service:
                self.toast_service.show_success(message)
        else:
            if self.toast_service:
                self.toast_service.show_error(message)

    def _on_delete_wallpaper(self, button, wallpaper):
        window = self.get_root()

        dialog = Adw.MessageDialog(
            transient_for=window,
            heading="Delete wallpaper?",
            body=f"Are you sure you want to delete '{wallpaper.filename}'?\nThis action cannot be undone.",
        )
        dialog.add_response("cancel", "Cancel")
        dialog.add_response("delete", "Delete")
        dialog.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")

        def on_response(dialog, response):
            if response == "delete":
                success, message = self.view_model.delete_wallpaper(wallpaper)
                if success:
                    if self.toast_service:
                        self.toast_service.show_success(message)
                    self.update_status(len(self.view_model.wallpapers))
                else:
                    if self.toast_service:
                        self.toast_service.show_error(message)

        dialog.connect("response", on_response)
        dialog.present()

    def _reset_refresh_flag(self):
        """Reset refreshing flag."""
        self.is_refreshing = False
        return False
